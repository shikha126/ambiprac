def lambda_handler(event , context):
    print("hello world from Terraform - lambda lab")
    return "hello world from Terraform - lambda lab"

    